# 💸 Personal Loan App – Full Stack Solution (India Compliant)

A full-stack personal loan application system built for the Indian market. Includes:

- 📱 Android Mobile App (User onboarding, loan application)
- 🛠️ Node.js + Express Backend API
- 🧑‍💼 Admin Dashboard (React + TailwindCSS)

## ⚙️ Tech Stack

- **Frontend (Admin)**: React + Tailwind CSS
- **Mobile App**: Android (Java/Kotlin)
- **Backend**: Node.js + Express.js
- **Database**: MongoDB
- **Authentication**: Phone number (OTP-based login)
- **File Storage**: Aadhaar/PAN uploads
- **Email Notifications**: Via backend
- **Compliance**: Designed with Indian lending guidelines in mind

## 📦 Features

### 👤 User App
- Phone number login (OTP-based)
- Upload PAN, Aadhaar
- Bank account linking (mock/UPI placeholder)
- CIBIL Score simulation
- Loan application & status tracking

### 🧑‍💼 Admin Dashboard
- View & filter loan applications
- Approve/Reject with real-time status change
- Export filtered data to CSV
- CIBIL + status filtering

## 🚀 Getting Started

### Backend (Node.js)
```bash
cd backend
npm install
npm start
```

### Admin Dashboard (React)
```bash
cd admin-dashboard
npm install
npm run dev
```

### Mobile App (Android)
- Open in Android Studio
- Sync Gradle and run on device/emulator

## ✅ Requirements

- Node.js >= 18
- MongoDB running locally or Mongo Atlas
- Android Studio for mobile app
- GitHub account to deploy backend (optional)

## 📂 Project Structure

```
loan_app_full_stack/
├── backend/
├── admin-dashboard/
└── mobile-app/
```

## 🛡️ Disclaimer

This project is a **demo** and should be adapted to comply with RBI and NBFC regulations for real deployments. Ensure legal and financial compliance before going live.

## 📫 Contact

Built by [ITPL Intellismart](https://github.com/itplintellismart-tech)  
📧 hello@yourcompany.com
