# Admin Dashboard
React admin panel for loan approvals.