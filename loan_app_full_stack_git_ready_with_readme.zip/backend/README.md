# Backend
Express API with MongoDB and Firebase Auth.